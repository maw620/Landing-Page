//Brought in a smooth scroll effect for the navigation
const scroll = new SmoothScroll('#nav a[href*="#"]', {
    speed: 1000
});
//added a color change button in the just for fun section
document.getElementById('btn').addEventListener('click', function() {
    document.getElementById('forfun').style.backgroundColor = 'yellow';
});